# Working Scrolling Patterns in JupyterLab Widgets

## Executive Summary

JupyterLab uses CSS containment (`contain: strict`) at the application level via `.jp-MainAreaWidget-ContainStrict`, but individual widgets **override this containment** with `overflow: visible` where needed, especially for scrolling areas.

## Key Finding: The Containment Override Pattern

### Application-Level Containment
**File**: `@jupyterlab/application/style/core.css`

```css
/* Top panel relaxes strict containment for menu painting */
#jp-top-panel {
  contain: style size !important;  /* Not strict! */
}
```

### Notebook-Level Containment
**File**: `@jupyterlab/notebook/style/base.css:59-61`

```css
.jp-MainAreaWidget-ContainStrict .jp-Notebook * {
  contain: strict;
}
```

This applies `contain: strict` to ALL elements in the notebook, which would break scrolling by default.

### Cell-Level Override
**File**: `@jupyterlab/notebook/style/base.css:63-65`

```css
.jp-Notebook .jp-Cell {
  overflow: visible;
}
```

**This is the critical pattern**: Cells explicitly override the strict containment with `overflow: visible`.

### Cell Wrappers Also Use Overflow Visible
**File**: `@jupyterlab/cells/style/widget.css:30-39`

```css
.jp-Cell-inputWrapper,
.jp-Cell-outputWrapper {
  display: flex;
  flex-direction: row;
  padding: 0;
  margin: 0;

  /* Added to reveal the box-shadow on the input and output collapsers. */
  overflow: visible;
}
```

## Working Scrolling Patterns

### 1. Output Areas (Scrollable Content)
**File**: `@jupyterlab/outputarea/style/base.css:11-13`

```css
.jp-OutputArea {
  overflow-y: auto;
}
```

**File**: `@jupyterlab/outputarea/style/base.css:47-55`

```css
.jp-OutputArea-output {
  width: 100%;
  height: auto;
  overflow: auto;
  user-select: text;
  -moz-user-select: text;
  -webkit-user-select: text;
  -ms-user-select: text;
}
```

Pattern: Direct scrolling with `overflow-y: auto` or `overflow: auto` on the container.

### 2. Scrolled Cell Outputs
**File**: `@jupyterlab/cells/style/widget.css:72-77`

```css
.jp-CodeCell.jp-mod-outputsScrolled .jp-Cell-outputArea {
  overflow-y: auto;
  max-height: 24em;
  margin-left: var(--jp-private-cell-scrolling-output-offset);
  resize: vertical;
}
```

Pattern: `overflow-y: auto` with `max-height` constraint, plus `resize: vertical` for user control.

### 3. Markdown Cell Output
**File**: `@jupyterlab/cells/style/widget.css:132-134`

```css
.jp-MarkdownOutput.jp-RenderedHTMLCommon {
  overflow: auto;
}
```

Pattern: Simple `overflow: auto` on rendered content.

### 4. Table of Contents (Sidebar Scrolling)
**File**: `@jupyterlab/toc/style/base.css:32-34`

```css
.jp-TableOfContents .jp-SidePanel-content {
  overflow-y: auto;
}
```

Pattern: `overflow-y: auto` on panel content area.

### 5. Windowed Panel (Virtual Scrolling)
**File**: `@jupyterlab/ui-components/style/windowedlist.css:6-11`

```css
.jp-WindowedPanel-outer {
  height: 100%;
  position: relative;
  overflow: auto;
  overflow-anchor: none;
}
```

**File**: `@jupyterlab/ui-components/style/windowedlist.css:17-22`

```css
.jp-WindowedPanel-viewport {
  position: absolute;
  left: 0;
  right: 0;
  overflow: visible;
}
```

Pattern: Outer container has `overflow: auto`, inner viewport uses `position: absolute` with `overflow: visible`.

### 6. Absolute Positioned Elements with Scrolling Parent

**Output Area Prompt Overlay** (`@jupyterlab/outputarea/style/base.css:65-74`):
```css
.jp-OutputArea-promptOverlay {
  position: absolute;
  top: 0;
  width: var(--jp-cell-prompt-width);
  height: 100%;
  /* ... */
}
```

The parent `.jp-OutputArea` has `overflow-y: auto` and children can use `position: absolute` without issues.

## Containment Usage Across JupyterLab

### Files Using `contain:` Property

1. **`@jupyterlab/application/style/core.css:55`**
   ```css
   #jp-top-panel {
     contain: style size !important;  /* Relaxed, not strict */
   }
   ```

2. **`@jupyterlab/application/style/skiplink.css:12`**
   ```css
   /* Skip link containment */
   contain: size style !important;
   ```

3. **`@jupyterlab/notebook/style/base.css:60`**
   ```css
   .jp-MainAreaWidget-ContainStrict .jp-Notebook * {
     contain: strict;  /* Applied to all, then overridden where needed */
   }
   ```

4. **`@jupyterlab/notebook/style/toolbar.css:24`**
   ```css
   /* Toolbar containment */
   contain: style size !important;
   ```

### Key Insight: No `contain: none` Found

**Important**: JupyterLab does NOT use `contain: none` anywhere in its codebase. Instead:
- It uses `contain: style size` (relaxed containment) at layout level
- It applies `contain: strict` at notebook level
- **It overrides with `overflow: visible` at component level**

## Absolute Positioning Patterns

### Cells use absolute positioning for collapsers
**File**: `@jupyterlab/cells/style/collapser.css:23`
```css
.jp-Collapser {
  position: absolute;
  /* ... */
}
```

**File**: `@jupyterlab/cells/style/widget.css:141`
```css
.jp-collapseHeadingButton {
  position: absolute;
  /* ... */
}
```

### Output areas use absolute positioning for overlays
**File**: `@jupyterlab/outputarea/style/base.css:66`
```css
.jp-OutputArea-promptOverlay {
  position: absolute;
  /* ... */
}
```

**File**: `@jupyterlab/outputarea/style/base.css:114`
```css
/* Before pseudo-element for cursor override */
body.lm-mod-override-cursor .jp-OutputArea-output.jp-mod-isolated::before {
  position: absolute;
  /* ... */
}
```

## Recommendations for WYSIWYG Editor

Based on these patterns, here's what we should do:

### 1. DO NOT use `contain: none`
This is not the JupyterLab pattern. The framework uses `contain: strict` then overrides with `overflow: visible`.

### 2. Follow the Cell Pattern
**Current problematic pattern**:
```css
.jp-MDWYSIWYGEditor-container {
  contain: none;  /* Don't do this! */
}
```

**Recommended pattern** (following `.jp-Cell` and `.jp-Cell-inputWrapper`):
```css
.jp-MDWYSIWYGEditor-container {
  overflow: visible;  /* Override the strict containment */
  /* Do NOT set contain at all - let it inherit */
}
```

### 3. For Scrollable Content Area
**Follow the Output Area Pattern**:
```css
.jp-MDWYSIWYGEditor-content {
  overflow-y: auto;
  overflow-x: hidden;
  height: 100%;
}
```

### 4. Structure Recommendation

```css
/* Container - override strict containment */
.jp-MDWYSIWYGEditor-container {
  display: flex;
  flex-direction: column;
  overflow: visible;  /* Like .jp-Cell */
  height: 100%;
}

/* Toolbar - no scrolling */
.jp-MDWYSIWYGEditor-toolbar {
  flex: 0 0 auto;
  overflow: visible;  /* Like .jp-Cell-inputWrapper */
}

/* Content - scrolling area */
.jp-MDWYSIWYGEditor-content {
  flex: 1 1 auto;
  overflow-y: auto;   /* Like .jp-OutputArea */
  overflow-x: hidden;
  position: relative;  /* For absolute children if needed */
}

/* Editor wrapper */
.jp-MDWYSIWYGEditor-editor {
  min-height: 100%;
  overflow: visible;  /* Editor can expand */
}
```

### 5. Why This Works

1. **Container with `overflow: visible`**: Allows the editor to participate in the layout without being clipped by strict containment
2. **Content with `overflow-y: auto`**: Provides the scrolling behavior
3. **No `contain: none`**: Follows JupyterLab's pattern of working within the containment system rather than breaking out of it
4. **Relative positioning**: Allows absolute positioned children (like toolbars, overlays) without breaking containment

## Current WYSIWYG Editor CSS Analysis

**File**: `style/editor.css`

### Current Pattern (GOOD - Mostly Correct!)

```css
/* Line 7-20: Main container */
.jp-MarkdownEditor {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;  /* This is fine - contains the layout */
}

/* Line 66-74: Scrollable content */
.jp-MarkdownEditor-content {
  flex: 1 1 auto;
  overflow-y: auto;      /* CORRECT: Scrolling area */
  overflow-x: hidden;
  min-height: 0;         /* CORRECT: Critical for flex scrolling */
  position: relative;    /* CORRECT: For absolute children */
}
```

### What's Working Well

1. **Flex layout with scrolling child**: Matches JupyterLab pattern
2. **`overflow-y: auto` on content area**: Exactly like `.jp-OutputArea`
3. **`min-height: 0`**: Critical for flex scrolling - good catch!
4. **`position: relative`**: Allows absolute children without breaking layout

### Potential Issues to Test

The current CSS doesn't explicitly handle the `contain: strict` that may be applied by `.jp-MainAreaWidget-ContainStrict`. If the widget is mounted in a strictly contained context, we should verify:

1. **Is the widget mounted inside `.jp-MainAreaWidget-ContainStrict`?**
   - If YES: We may need to add `overflow: visible` to `.jp-MarkdownEditor`
   - If NO: Current CSS should work fine

2. **Test for absolute positioning issues**
   - Check if toolbar dropdowns/menus are clipped
   - Verify scrolling works in strictly contained context

### Recommended Safety Addition

Add this to ensure compatibility with strict containment:

```css
/* Main editor container */
.jp-MarkdownEditor {
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  overflow: visible;  /* ADD: Override strict containment like .jp-Cell */
  /* Remove: overflow: hidden; */
}
```

This changes line 15 from `overflow: hidden` to `overflow: visible`, matching the `.jp-Cell` pattern.

## Summary

The JupyterLab pattern is:
1. Apply `contain: strict` at the application level (`.jp-MainAreaWidget-ContainStrict`)
2. Override with `overflow: visible` at the component level (`.jp-Cell`, `.jp-Cell-inputWrapper`)
3. Use `overflow-y: auto` on scrollable content areas (`.jp-OutputArea`, `.jp-Cell-outputArea`)
4. Never use `contain: none` - it's not part of the JupyterLab CSS patterns

**Our WYSIWYG editor already follows 95% of this pattern!** The only suggested change is:
- Change `.jp-MarkdownEditor` from `overflow: hidden` to `overflow: visible`

This pattern allows scrolling to work correctly while maintaining the performance benefits of CSS containment for the rest of the application.
