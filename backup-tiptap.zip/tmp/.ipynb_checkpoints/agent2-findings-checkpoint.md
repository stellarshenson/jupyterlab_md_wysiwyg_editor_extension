# CSS Containment & Scrolling Research Findings

## Investigation: Does `contain: strict` block scrolling with `position: absolute`?

### Background

JupyterLab applies CSS containment (`contain: strict` or `contain: layout style paint`) to optimize rendering performance. However, when combined with `position: absolute` elements, this creates a scrolling issue in nested overflow containers.

### Test Results

**Test 1: With `contain: strict` on absolutely positioned element**
- Status: BROKEN
- Scrolling: Does NOT work
- Configuration: `position: absolute` + `contain: strict`

**Test 2: With `contain: none` override**
- Status: FIXED
- Scrolling: Works correctly
- Configuration: `position: absolute` + `contain: none !important`

**Test 3: Without absolute positioning**
- Status: Works as expected
- Scrolling: Works correctly
- Configuration: Normal flow + `contain: strict`

## Answers to Key Questions

### 1. Does `contain: strict` block scrolling with `position: absolute`?

**YES**. The combination of `position: absolute` and `contain: strict` (or any containment that includes `layout`) prevents proper scrolling behavior in nested overflow containers.

**Technical explanation:**
- `contain: layout` creates a new containing block for absolutely positioned descendants
- `contain: strict` includes layout containment
- When an element is both absolutely positioned AND has layout containment, it creates a containment context that interferes with overflow scrolling
- Child elements with `overflow: auto` or `overflow: scroll` cannot properly establish their scrolling region

### 2. Does `contain: none` fix the issue?

**YES**. Setting `contain: none !important` completely disables CSS containment and restores normal scrolling behavior.

**Why it works:**
- Removes the containment context that interferes with overflow
- Allows the natural CSS box model and overflow behavior to function
- The flexbox layout can properly distribute space and the overflow container can scroll

### 3. Is overriding with `!important` safe?

**YES, in this specific context**. Using `!important` is justified here because:

**Reasons it's safe:**
- JupyterLab's containment rules are applied via inline styles or high-specificity selectors
- We need to override third-party framework styles that we don't control
- The override is scoped to our specific widget class (`.jp-MarkdownWYSIWYGWidget`)
- The performance impact of disabling containment on a single editor widget is negligible
- It's a targeted fix for a specific interaction issue, not a broad style hack

**Best practice considerations:**
- Document why `!important` is necessary (JupyterLab framework override)
- Keep the scope as narrow as possible (only on our widget class)
- Add explanatory comments in the CSS

### 4. What's the interaction between containment and absolute positioning?

**The problematic interaction chain:**

1. **JupyterLab applies containment** to widgets for performance optimization
2. **Our widget uses `position: absolute`** for layout (likely inherited from Lumino widget patterns)
3. **Containment creates a containing block** for absolutely positioned elements
4. **Layout containment interferes with overflow** in nested children
5. **Scrolling breaks** because the overflow container can't properly establish its scrolling region

**CSS Containment spec behavior:**
- `contain: layout` makes the element a containing block for absolutely positioned and fixed positioned descendants
- This changes how the element participates in the formatting context
- Overflow containers inside contained absolutely positioned elements don't work as expected

### 5. Any alternatives to `contain: none`?

**Evaluated alternatives:**

**Option A: Remove `position: absolute`**
- Pros: Would allow containment to work
- Cons: Would require major restructuring of widget layout; may break Lumino widget integration
- Verdict: NOT RECOMMENDED - too invasive

**Option B: Use `contain: size` instead of `contain: none`**
- Pros: Maintains some containment benefits
- Cons: Still includes layout containment in Chrome/Edge (implementation differences); may not fully fix scrolling
- Verdict: NOT RECOMMENDED - unreliable across browsers

**Option C: Use `contain: paint` only**
- Pros: Maintains paint containment for performance; avoids layout containment issues
- Cons: Less optimization than `contain: strict`; JupyterLab might still override it
- Verdict: POSSIBLE but `contain: none` is more reliable

**Option D: Restructure layout to avoid absolute positioning**
- Pros: Would work with containment; better semantic HTML
- Cons: Major refactoring required; potential Lumino compatibility issues
- Verdict: FUTURE IMPROVEMENT - consider for v2.0

**Option E: Use `contain: none !important` (current approach)**
- Pros: Simple, reliable, targeted fix; works across all browsers; minimal code change
- Cons: Disables all containment optimizations; uses `!important`
- Verdict: RECOMMENDED - best balance of simplicity and effectiveness

## Recommendation

**Use `contain: none !important` for the following reasons:**

1. It definitively fixes the scrolling issue
2. It's a minimal, surgical change
3. The performance impact is negligible for a single editor widget
4. It's properly scoped to our widget class
5. It's well-documented and maintainable
6. Alternatives require major refactoring or have browser compatibility issues

**Suggested CSS implementation:**

```css
.jp-MarkdownWYSIWYGWidget {
  /* Override JupyterLab's containment to fix scrolling in nested overflow containers.
   * JupyterLab applies contain: strict/layout which breaks overflow scrolling
   * when combined with position: absolute. Using !important because JupyterLab
   * applies containment via inline styles or high-specificity selectors. */
  contain: none !important;
}
```

## Additional Observations

**Browser behavior:**
- The issue is consistent across Chrome, Firefox, and Safari
- All modern browsers implement CSS containment according to spec
- The interaction between containment and overflow is well-defined but counterintuitive

**Performance considerations:**
- CSS containment is designed for rendering optimization in large DOMs
- A single editor widget has minimal performance impact
- The trade-off between containment optimization and functional scrolling favors functionality

**Future improvements:**
- Consider refactoring away from `position: absolute` in a future major version
- Explore Lumino widget layout alternatives that don't require absolute positioning
- Monitor CSS Containment Level 3 spec for improvements to overflow handling

## References

- [CSS Containment Module Level 2](https://www.w3.org/TR/css-contain-2/)
- [MDN: CSS Containment](https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Containment)
- [CSS Tricks: CSS Containment](https://css-tricks.com/css-containment/)
