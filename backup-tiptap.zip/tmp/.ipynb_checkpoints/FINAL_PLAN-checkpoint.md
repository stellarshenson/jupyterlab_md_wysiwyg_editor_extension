# Final Execution Plan - WYSIWYG Editor CSS Fix

## Executive Summary

**Root Cause Discovered**: Debug output shows Lumino applies inline `contain: strict` which blocks scrolling!

**Two Approaches Available**:
1. **Quick Test** - Apply targeted fix based on discovery (5 min)
2. **Agentic Research** - Use 3 agents to find proper solution (15 min)

## Approach 1: Quick Test Fix (RECOMMENDED)

### The Fix
Based on debug output showing `style="position: absolute; contain: strict; ..."`, apply these CSS changes:

```css
/* Override Lumino containment that blocks scrolling */
.lm-Widget.jp-MarkdownEditor {
  contain: none !important;
}

/* Remove white frame from parent Document */
.jp-Document .lm-Widget.jp-MarkdownEditor {
  margin: 0;
  border: 0;
}

/* Parent document padding (white frame source) */
.jp-MainAreaWidget.jp-Document {
  padding: 0;
}

/* Ensure flex layout works with absolute positioning */
.jp-MarkdownEditor {
  display: flex;
  flex-direction: column;
  height: 100%;
}

/* Make content area scrollable */
.jp-MarkdownEditor-content {
  flex: 1 1 auto;
  min-height: 0;  /* Critical for flex scrolling */
  overflow-y: auto;
}

/* ProseMirror padding */
.jp-MarkdownEditor-content .ProseMirror {
  padding: 16px 32px;
  min-height: 100%;
}
```

### Justification for !important
- `contain: none !important` - **Required** to override inline `contain: strict`
- Inline styles have highest specificity, so !important is the only way

### Steps
1. Update `style/editor.css` and `style/base.css`
2. Remove other unnecessary !important flags
3. Rebuild with `make build && make install`
4. Test in JupyterLab
5. Refine as needed

**Time**: 5-10 minutes

---

## Approach 2: Agentic Research (THOROUGH)

### Agent Tasks

#### Agent 1: JupyterLab CSS Rules Hunter
**Task**: Find source of white frame and containment rules
- Search for `.jp-Document` styles
- Search for `.jp-MainAreaWidget-ContainStrict`
- Find `.lm-Widget` positioning rules

**Deliverable**: `tmp/agent1-css-rules.md`

#### Agent 2: CSS Containment Expert
**Task**: Research scrolling with `contain: strict` and `position: absolute`
- Test if flex+scroll works with containment
- Find if `contain: none` override is safe
- Create HTML test case

**Deliverable**: `tmp/agent2-containment-test.html` + findings

#### Agent 3: Working Patterns Finder
**Task**: Find how other JupyterLab widgets handle scrolling
- Study CodeMirror, notebook cells CSS
- Find proven patterns for scrolling
- Document what actually works

**Deliverable**: `tmp/agent3-working-patterns.md`

### Steps
1. Launch 3 agents in parallel (single message, 3 Task tools)
2. Wait for results (~10 minutes)
3. Synthesize findings
4. Implement validated solution
5. Test and refine

**Time**: 15-20 minutes

---

## My Recommendation

**Start with Approach 1 (Quick Test)**

**Reasoning**:
1. We have high confidence in root cause (debug output is clear)
2. The fix is straightforward and targeted
3. Can always run agents if test doesn't work
4. Faster iteration cycle

**If quick test works:**
- Refine CSS for cleaner selectors
- Document why !important is needed for `contain`
- Remove debug logging
- Done!

**If quick test fails:**
- We learn what doesn't work
- Run agents with more specific questions
- Have better context for agent tasks

## Final Decision

**I propose**: Execute Approach 1 immediately.

**If you approve**, I will:
1. Update CSS files with targeted fixes
2. Remove unnecessary !important flags
3. Rebuild extension
4. Create summary of changes

**If you want agents instead**: I'll launch 3 agents in parallel to research the proper solution.

**Your call!** Which approach do you prefer?
- **A**: Quick test fix now
- **B**: Run 3 agents first
- **C**: Both in parallel (test + agents)
