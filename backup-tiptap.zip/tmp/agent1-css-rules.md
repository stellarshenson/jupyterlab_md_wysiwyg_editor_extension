# JupyterLab CSS Rules Investigation: Document Widget Styling

## Executive Summary

The "white frame" around content in JupyterLab is created by a combination of:
1. `var(--jp-layout-color0)` background on `.lm-DockPanel-widget` and `.lm-TabPanel-stackedPanel`
2. Border styling on these same elements
3. Padding on `#jp-main-dock-panel` (5px)
4. CSS containment rules applied via `.jp-MainAreaWidget-ContainStrict`

## Detailed Findings

### 1. `.jp-Document` CSS Rules

**Location**: `/node_modules/@jupyterlab/filebrowser/style/base.css:455-459`

```css
.jp-Document {
  min-width: 120px;
  min-height: 120px;
  outline: none;
}
```

**Location**: `/node_modules/@jupyterlab/notebook/style/base.css:39-42`

```css
.jp-NotebookPanel.jp-Document {
  min-width: 240px;
  min-height: 120px;
}
```

**Analysis**: The `.jp-Document` class itself does NOT create the white frame. It only sets minimum dimensions and removes outline. No padding or background is applied directly to this class.

---

### 2. `.jp-MainAreaWidget` CSS Rules

**Location**: `/node_modules/@jupyterlab/apputils/style/mainareawidget.css:6-24`

```css
.jp-MainAreaWidget > :focus {
  outline: none;
}

.jp-MainAreaWidget .jp-MainAreaWidget-error {
  padding: 6px;
}

.jp-MainAreaWidget .jp-MainAreaWidget-error > pre {
  width: auto;
  padding: 10px;
  background: var(--jp-error-color3);
  border: var(--jp-border-width) solid var(--jp-error-color1);
  border-radius: var(--jp-border-radius);
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size1);
  white-space: pre-wrap;
  word-wrap: break-word;
}
```

**Location**: `/node_modules/@jupyterlab/application/style/core.css:42-44`

```css
#jp-main-dock-panel[data-mode='single-document'] .jp-MainAreaWidget {
  border: none;
}
```

**Analysis**: The `.jp-MainAreaWidget` itself has minimal styling. In single-document mode, borders are removed. The padding around widgets comes from the parent container, not MainAreaWidget.

---

### 3. `.jp-MainAreaWidget-ContainStrict` - CSS Containment Rules

**Location**: `/node_modules/@jupyterlab/notebook/style/base.css:59-61`

```css
.jp-MainAreaWidget-ContainStrict .jp-Notebook * {
  contain: strict;
}
```

**Analysis**: This is a **CRITICAL** rule that applies `contain: strict` to all elements inside notebooks when the `jp-MainAreaWidget-ContainStrict` class is present. This is the source of the containment issues.

**What `contain: strict` does**:
- Equivalent to `contain: size layout style paint`
- Creates a new containing block for absolutely positioned elements
- Prevents content from affecting layout outside the container
- Can cause positioning and overflow issues if not properly accounted for

**Other containment rules found**:

**Location**: `/node_modules/@jupyterlab/application/style/core.css:55`
```css
#jp-top-panel {
  /* relax lumino strict CSS contaiment to allow painting the menu bar item
  over the menu in order to create an illusion of partial border */
  contain: style size !important;
}
```

**Location**: `/node_modules/@jupyterlab/notebook/style/toolbar.css:24`
```css
/* Containment rule for notebook toolbar */
contain: style size !important;
```

---

### 4. `.lm-Widget` Positioning and Containment Rules

**Location**: `/node_modules/@lumino/widgets/style/widget.css:15-22`

```css
.lm-Widget {
  box-sizing: border-box;
  position: relative;
}

.lm-Widget.lm-mod-hidden {
  display: none !important;
}
```

**Analysis**: Lumino widgets use `position: relative` by default. This is standard and doesn't create containment issues. No `contain` property is applied at the base widget level.

**Position absolute usage in Lumino** (from various files):
- `.lm-CommandPalette-content`: `position: absolute` (commandpalette.css:70)
- `.lm-DockPanel-handle:after`: `position: absolute` (dockpanel.css:36)
- `.lm-Menu`: `position: absolute` (menu.css:17)
- `.lm-ScrollBar-thumb`: `position: absolute` (scrollbar.css:45)
- `.lm-SplitPanel-handle`: `position: absolute` (splitpanel.css:28)

These are all internal to their respective widgets and don't affect document content.

---

### 5. The "White Frame" Source

**Location**: `/node_modules/@jupyterlab/application/style/dockpanel.css:14-20`

```css
.lm-DockPanel-widget,
.lm-TabPanel-stackedPanel {
  background: var(--jp-layout-color0);
  border-left: var(--jp-border-width) solid var(--jp-border-color1);
  border-right: var(--jp-border-width) solid var(--jp-border-color1);
  border-bottom: var(--jp-border-width) solid var(--jp-border-color1);
}
```

**THIS IS THE PRIMARY SOURCE OF THE WHITE FRAME**

**Location**: `/node_modules/@jupyterlab/application/style/core.css:34-40`

```css
#jp-main-dock-panel {
  padding: 5px;
}

#jp-main-dock-panel[data-mode='single-document'] {
  padding: 0;
}
```

**Combined Effect**:
1. The main dock panel has 5px padding (removed in single-document mode)
2. Each widget (`.lm-DockPanel-widget`) gets a white background (`--jp-layout-color0`)
3. Borders are added on left, right, and bottom
4. This creates the visible "white frame" around content

---

## Hierarchy and Structure

```
#jp-main-dock-panel (padding: 5px, background: --jp-layout-color3)
  └─ .lm-DockPanel-widget (background: --jp-layout-color0, borders)
      └─ .lm-TabPanel-stackedPanel (background: --jp-layout-color0, borders)
          └─ .jp-MainAreaWidget (no padding/background)
              └─ .jp-Document (min-width/height only)
                  └─ Content (your widget)
```

---

## CSS Variables (from inspection)

Based on the CSS rules found, these variables control the layout:

- `--jp-layout-color0`: Main content background (typically white in light theme)
- `--jp-layout-color1`: UI panel background (slightly darker)
- `--jp-layout-color2`: Secondary UI elements
- `--jp-layout-color3`: Outermost background (darkest)
- `--jp-border-width`: Standard border width (typically 1px)
- `--jp-border-color0`: Primary border color
- `--jp-border-color1`: Secondary border color

---

## Recommendations for Safe Override

### Option 1: Work Within the System (Recommended)
Accept the white background and borders as part of JupyterLab's design system:

```css
/* Your widget fills the available space inside .jp-Document */
.jp-MarkdownWYSIWYGEditor {
  width: 100%;
  height: 100%;
  background: var(--jp-layout-color0); /* Match parent */
  overflow: auto;
}
```

### Option 2: Override Background Only
Remove the white background but keep borders:

```css
/* Apply to your widget's parent container */
.jp-MarkdownWYSIWYGWidget .lm-DockPanel-widget,
.jp-MarkdownWYSIWYGWidget .lm-TabPanel-stackedPanel {
  background: transparent !important;
}
```

**Risk**: Low - This only affects your widget type.

### Option 3: Remove Borders and Background
Complete removal of the frame:

```css
.jp-MarkdownWYSIWYGWidget .lm-DockPanel-widget,
.jp-MarkdownWYSIWYGWidget .lm-TabPanel-stackedPanel {
  background: transparent !important;
  border: none !important;
}
```

**Risk**: Low - Scoped to your widget only.

### Option 4: Override Containment (Caution Required)
Only if you're experiencing specific containment issues:

```css
/* Be very specific to avoid breaking other widgets */
.jp-MainAreaWidget-ContainStrict .jp-MarkdownWYSIWYGEditor,
.jp-MainAreaWidget-ContainStrict .jp-MarkdownWYSIWYGEditor * {
  contain: none !important;
}
```

**Risk**: Medium-High - Could affect layout calculations and scrolling behavior. Only use if you have specific issues with:
- Fixed positioning
- Absolute positioning escaping container
- Scroll performance

**Better Alternative**: Instead of removing containment entirely, relax it:

```css
.jp-MainAreaWidget-ContainStrict .jp-MarkdownWYSIWYGEditor {
  contain: style !important; /* Keep style containment, remove layout/size/paint */
}
```

---

## Summary of Containment

**Where containment is applied**:
1. `#jp-top-panel`: `contain: style size !important` (allows menu painting)
2. `.jp-MainAreaWidget-ContainStrict .jp-Notebook *`: `contain: strict` (ALL notebook elements)
3. Notebook toolbar: `contain: style size !important`

**Where it's NOT applied**:
- `.lm-Widget` (base class)
- `.jp-MainAreaWidget`
- `.jp-Document`
- Most other layout containers

**Key Insight**: The strict containment is specifically for notebook cells, not all document widgets. Your custom widget may not need to inherit this containment unless it's explicitly added to your widget class.

---

## Safe Override Strategy

**Recommended approach**:

```css
/* In your style/editor.css */

/* Remove white frame if desired */
.jp-MarkdownWYSIWYGWidget.jp-MainAreaWidget > .lm-DockPanel-widget {
  background: transparent;
  border: none;
}

/* Ensure your editor fills the space */
.jp-MarkdownWYSIWYGEditor {
  width: 100%;
  height: 100%;
  overflow: auto;
  box-sizing: border-box;
}

/* Only override containment if you experience specific issues */
/* Start without this - add only if needed */
/*
.jp-MainAreaWidget-ContainStrict .jp-MarkdownWYSIWYGEditor {
  contain: style !important;
}
*/
```

This approach:
1. Is scoped to your widget (`.jp-MarkdownWYSIWYGWidget`)
2. Doesn't affect other widgets
3. Works with JupyterLab's layout system
4. Leaves containment alone unless you discover specific issues

---

## Questions Answered

1. **What padding/background does `.jp-Document` have by default?**
   - NONE. It only has `min-width: 120px`, `min-height: 120px`, and `outline: none`

2. **What does `.jp-MainAreaWidget-ContainStrict` apply?**
   - It applies `contain: strict` to all child elements (`.jp-Notebook *`)
   - This is specific to notebooks and creates a strict containment boundary

3. **Where does the `contain: strict` come from?**
   - `/node_modules/@jupyterlab/notebook/style/base.css:60`
   - Applied only when the `jp-MainAreaWidget-ContainStrict` class is present
   - Used for notebook cells to improve rendering performance

4. **Can we override it safely?**
   - YES, but be specific and scope it to your widget only
   - Better to relax to `contain: style` rather than removing entirely
   - Test thoroughly for layout, scrolling, and positioning issues
   - The containment may not even apply to your widget unless you explicitly add that class
