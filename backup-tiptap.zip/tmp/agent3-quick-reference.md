# Quick Reference: JupyterLab Scrolling Patterns

## The Pattern Hierarchy

```
.jp-MainAreaWidget-ContainStrict
  └─ * { contain: strict; }              ← Applied to ALL children
      │
      ├─ .jp-Cell
      │   └─ overflow: visible            ← OVERRIDE containment
      │
      ├─ .jp-Cell-inputWrapper
      │   └─ overflow: visible            ← OVERRIDE containment
      │
      ├─ .jp-Cell-outputWrapper
      │   └─ overflow: visible            ← OVERRIDE containment
      │
      └─ .jp-Cell-outputArea (scrolled)
          └─ overflow-y: auto             ← SCROLLING area
          └─ max-height: 24em
```

## Key Files with Scrolling Examples

| Component | File | Pattern |
|-----------|------|---------|
| Output Area | `@jupyterlab/outputarea/style/base.css:12` | `overflow-y: auto` |
| Scrolled Outputs | `@jupyterlab/cells/style/widget.css:73` | `overflow-y: auto` + `max-height: 24em` |
| Markdown Output | `@jupyterlab/cells/style/widget.css:133` | `overflow: auto` |
| TOC Panel | `@jupyterlab/toc/style/base.css:33` | `overflow-y: auto` |
| Windowed Panel | `@jupyterlab/ui-components/style/windowedlist.css:9` | `overflow: auto` |
| Cell Wrappers | `@jupyterlab/cells/style/widget.css:38` | `overflow: visible` |
| Cells | `@jupyterlab/notebook/style/base.css:64` | `overflow: visible` |

## Three-Level Pattern

### Level 1: Containment (Application)
```css
.jp-MainAreaWidget-ContainStrict .jp-Notebook * {
  contain: strict;
}
```

### Level 2: Override (Component)
```css
.jp-Cell,
.jp-Cell-inputWrapper,
.jp-Cell-outputWrapper {
  overflow: visible;  /* Override strict containment */
}
```

### Level 3: Scrolling (Content)
```css
.jp-OutputArea,
.jp-Cell-outputArea {
  overflow-y: auto;   /* Enable scrolling */
}
```

## For WYSIWYG Editor

### Current Structure
```
.jp-MarkdownEditor (container)
  └─ .jp-MarkdownEditor-toolbar
  └─ .jp-MarkdownEditor-content (scrolls)
      └─ .ProseMirror (editor)
```

### Recommended CSS
```css
/* Container - override containment */
.jp-MarkdownEditor {
  overflow: visible;  /* Change from: overflow: hidden */
}

/* Content - scrolling area (ALREADY CORRECT) */
.jp-MarkdownEditor-content {
  overflow-y: auto;
  overflow-x: hidden;
  min-height: 0;      /* Critical for flex */
  position: relative;
}
```

## Why This Works

1. **Containment at app level**: Performance optimization for rendering
2. **Override at component level**: Allows layout to work correctly
3. **Scrolling at content level**: Provides actual scrolling behavior

## What NOT to Do

❌ **Don't use `contain: none`** - Not part of JupyterLab patterns
❌ **Don't fight the system** - Work with containment, not against it
❌ **Don't apply `overflow: auto` to container** - Apply to content area instead

## What TO Do

✅ **Use `overflow: visible`** on containers (like `.jp-Cell`)
✅ **Use `overflow-y: auto`** on scrollable content (like `.jp-OutputArea`)
✅ **Use `min-height: 0`** on flex children that scroll
✅ **Use `position: relative`** on scrolling containers for absolute children
