# Investigation Scratchpad - WYSIWYG Editor Styling Issues

## Timeline of Changes

### Initial Issues Reported
1. Toolbar displayed vertically, taking 50% of screen - text labels too long
2. WYSIWYG editor text touches frame borders (no margin)
3. No scrolling functionality

### Attempted Fixes

#### Fix Attempt 1: Basic CSS Updates
- Changed toolbar to horizontal layout with `flex-direction: row`
- Changed button labels to short symbols (B, I, S, etc.)
- Added padding to ProseMirror: `padding: 16px 32px`
- Added `overflow-y: auto` to content area
- **Result**: Background color changed, but no other improvements

#### Fix Attempt 2: Added !important Flags
- Added `!important` to all CSS properties
- Added DocumentWidget CSS overrides in base.css
- **Result**: Still no improvement
- **User feedback**: Using !important is sloppy, need proper solution

#### Fix Attempt 3: Added Debug Logging
- Added console.log statements to output DOM structure
- Logging computed styles for all relevant elements
- **Status**: Waiting for console output from user

## Current Understanding

### What Works
- Toolbar renders horizontally with correct button labels
- Background color CSS is being applied
- CSS file is definitely loading

### What Doesn't Work
1. **White frame/border** around content - suggests wrapper element with padding/background
2. **No margins** on content - ProseMirror padding not applying
3. **No scrolling** - overflow-y: auto not working

### Hypotheses Ranking

**Most Likely (90% confidence):**
1. **DOM structure mismatch** - We're targeting wrong elements or missing wrapper layers
   - Evidence: Some CSS applies (bg color) but layout CSS doesn't
   - DocumentWidget likely adds wrappers we're not styling

**Likely (70% confidence):**
2. **Flexbox parent issue** - overflow-y: auto needs constrained height parent
   - Evidence: Common issue with flex layouts
   - Parent might not have display: flex or proper height

**Possible (40% confidence):**
3. **TipTap inline styles** - ProseMirror might apply inline padding overrides
   - Evidence: TipTap often uses inline styles for editor view
   - Would explain why padding doesn't apply

**Unlikely (20% confidence):**
4. **CSS specificity** - JupyterLab styles override ours
   - Evidence: Background color works, so our CSS loads
   - But layout properties might have more specific selectors

## Key Questions to Answer

1. What is the actual DOM hierarchy from DocumentWidget down to ProseMirror?
2. Which element has the white background?
3. What are the computed styles on content container?
4. Is the parent a flex container?
5. Does ProseMirror have inline styles?

## Next Steps

### Immediate: Get Debug Output
Need user to provide console output showing:
- Actual DOM structure
- Computed styles on all elements
- Parent widget class names

### After Debug Output
Based on findings, likely need to:
1. Identify correct CSS selectors for actual DOM structure
2. Ensure parent has proper flex/height constraints
3. Possibly use TipTap editorProps to set padding via attributes
4. Remove all !important flags and use proper specificity

## Code Locations

### Files Modified
- `src/widget.ts` - Added debug logging at line 95-129
- `style/editor.css` - Main editor styles (has !important flags to remove)
- `style/base.css` - DocumentWidget overrides (has !important flags to remove)

### Key CSS Classes
- `.jp-MarkdownEditor` - Main container
- `.jp-MarkdownEditor-content` - Content area (should scroll)
- `.ProseMirror` - TipTap's editor element
- `.jp-DocumentWidget-content` - Parent wrapper (possibly)
- `.lm-Widget` - Lumino base class (possibly relevant)

## Observations from Screenshot

Looking at user's screenshot `2025-10-18 21_52_10-.png`:
- Dark theme is active
- Content area has lighter background (white/gray frame visible)
- No visible scrollbar
- Text appears to start at very edge of content area
- Toolbar looks correct with horizontal layout

## Testing Strategy for Agents

Once we understand the root cause from debug output, we can test with agents:

### Agent 1: DOM Structure Validator
**Task**: Create minimal HTML reproduction of the issue
- Build static HTML with same DOM structure
- Apply same CSS
- Verify if scrolling/margins work in isolation

### Agent 2: CSS Selector Hunter
**Task**: Find correct selectors by inspecting JupyterLab source
- Search JupyterLab docregistry source for DocumentWidget CSS
- Identify what classes/structure DocumentWidget actually creates
- Find what needs to be overridden

### Agent 3: TipTap Configuration Expert
**Task**: Research TipTap/ProseMirror styling best practices
- Check if editorProps.attributes needed for padding
- Check if scrollThreshold/scrollMargin needed
- Find examples of TipTap in flex containers

## Decision Points

### If DOM structure is different than expected:
→ Update CSS selectors to match actual structure
→ May need to target Lumino widget classes

### If parent isn't flex container:
→ Add display: flex to parent via base.css
→ Ensure height is constrained (not auto)

### If inline styles are the issue:
→ Use TipTap editorProps to set styles
→ Or use CSS with higher specificity (attribute selectors)

### If it's a ProseMirror-specific issue:
→ Add ProseMirror-specific CSS for scroll handling
→ Configure editor initialization with scroll options

## Success Criteria

Fix will be successful when:
1. ✓ No white frame around content
2. ✓ Content has 32px horizontal, 16px vertical margins
3. ✓ Vertical scrolling works when content exceeds viewport
4. ✓ Scrollbar appears when needed
5. ✓ All CSS written properly without !important flags
6. ✓ Styling matches JupyterLab markdown viewer aesthetic
