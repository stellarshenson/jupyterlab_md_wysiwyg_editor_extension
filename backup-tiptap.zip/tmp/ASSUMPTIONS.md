# WYSIWYG Editor Styling Issues - Root Cause Analysis

## Problem Statement
Despite CSS changes being applied (background color changed), three critical issues persist:
1. White frame/border around the editor content
2. No margins/padding on markdown content (text touches edges)
3. No scrolling functionality (neither mouse wheel nor scrollbar)

## Observations from Screenshot
- Background color CSS is being applied (confirms CSS is loading)
- Toolbar is rendering correctly with horizontal layout
- Content area appears to have a white/light background distinct from surrounding dark theme
- No visible margins between content and editor boundaries

## Hypotheses & Testing Strategies

### Hypothesis 1: CSS Specificity Issue
**Theory**: JupyterLab's default styles have higher specificity than our overrides, even with `!important`.

**Evidence**:
- Some CSS properties apply (background color) but layout properties don't
- Could be inline styles or more specific selectors in JupyterLab core

**Test**:
1. Use browser DevTools to inspect actual computed styles
2. Check if styles are being overridden by more specific selectors
3. Install Chromium and use remote debugging to inspect live DOM

**Validation Command**:
```bash
# Install Chromium for DevTools inspection
sudo apt-get update
sudo apt-get install -y chromium-browser
```

### Hypothesis 2: Widget DOM Structure Mismatch
**Theory**: Our CSS targets wrong elements - the actual DOM structure may differ from expected.

**Evidence**:
- We're targeting `.jp-MarkdownEditor-content` and `.ProseMirror`
- Actual structure might have additional wrapper elements
- DocumentWidget may add containers we're not aware of

**Test**:
1. Add console.log statements in widget.ts to output DOM structure
2. Inspect actual HTML hierarchy using browser DevTools
3. Check if TipTap creates additional wrapper divs

**Validation Approach**:
```typescript
// Add to widget.ts _initializeEditor():
console.log('Editor container HTML:', this.node.innerHTML);
console.log('Content container classes:', contentContainer.className);
```

### Hypothesis 3: TipTap Inline Styles Overriding CSS
**Theory**: TipTap's editor initialization may apply inline styles that override our CSS.

**Evidence**:
- ProseMirror/TipTap often applies inline styles for layout
- Inline styles have highest specificity (except !important)
- Scrolling behavior might be controlled by TipTap config

**Test**:
1. Check TipTap/ProseMirror initialization options
2. Look for editorProps that might control styling
3. Inspect if ProseMirror is adding style attributes to DOM

**Validation**:
```typescript
// Check editor initialization options in editor.ts
// Look for editorProps, attributes, parseOptions
```

### Hypothesis 4: Flexbox Layout Not Applied Correctly
**Theory**: Parent container flex settings prevent proper scrolling/sizing.

**Evidence**:
- `overflow-y: auto` requires proper height constraints
- Flex: 1 1 auto might not work if parent isn't flex container
- min-height: 0 might be overridden

**Test**:
1. Check if DocumentWidget wrapper is flex container
2. Verify parent height is constrained (not auto)
3. Test with explicit height values instead of flex

**Validation**:
```css
/* Test with explicit constraints */
.jp-MarkdownEditor-content {
  height: 100vh !important;
  max-height: calc(100vh - 100px) !important;
}
```

### Hypothesis 5: ProseMirror editorView Configuration
**Theory**: TipTap's editorView might need specific attributes or scrollThreshold settings.

**Evidence**:
- ProseMirror has dedicated scrolling mechanisms
- May need scrollThreshold or scrollMargin configuration
- Editor attributes might control padding/margin behavior

**Test**:
1. Review TipTap editor initialization for missing scroll config
2. Check if editorProps.attributes needed for styling
3. Look at ProseMirror documentation for scroll handling

**Validation**:
```typescript
// In editor.ts, add to Editor config:
editorProps: {
  attributes: {
    style: 'padding: 16px 32px; overflow-y: auto;'
  },
  scrollThreshold: 0,
  scrollMargin: 0
}
```

### Hypothesis 6: White Frame is from DocumentWidget Content Wrapper
**Theory**: There's a `.jp-DocumentWidget-content` or similar wrapper we're not styling.

**Evidence**:
- We added CSS for `.jp-DocumentWidget-content` but may not be targeting correctly
- JupyterLab 4.x might use different class names
- Could be shadow DOM or CSS modules

**Test**:
1. Inspect actual class names in browser DevTools
2. Search JupyterLab source for DocumentWidget CSS classes
3. Check if using wrong selector (e.g., should be `.lm-Widget`)

**Validation Command**:
```bash
# Search JupyterLab source for DocumentWidget styles
grep -r "DocumentWidget" node_modules/@jupyterlab/docregistry/style/
```

## Recommended Testing Order

1. **Install Chromium & Enable Remote Debugging** (15 min)
   - Install browser: `sudo apt-get install chromium-browser`
   - Launch JupyterLab with remote debugging enabled
   - Use DevTools to inspect live DOM and computed styles

2. **Add Debug Logging** (5 min)
   - Add console.log to widget.ts showing DOM structure
   - Log computed styles of key elements
   - Rebuild and check browser console

3. **Test DOM Structure** (10 min)
   - Verify actual class names and hierarchy
   - Identify any wrapper elements we missed
   - Document actual vs expected structure

4. **Test TipTap Configuration** (10 min)
   - Add editorProps with inline styles as test
   - Configure scroll properties
   - Test if inline styles work when CSS doesn't

5. **Test Alternative CSS Approaches** (10 min)
   - Try explicit heights instead of flex
   - Test with data attributes instead of classes
   - Try :host selector if shadow DOM

## Expected Outcomes

**If Hypothesis 1 (CSS Specificity)**: DevTools will show our rules crossed out
**If Hypothesis 2 (DOM Mismatch)**: Element inspection will show different class names
**If Hypothesis 3 (Inline Styles)**: Elements will have style="" attributes
**If Hypothesis 4 (Flexbox)**: Parent containers won't have display: flex
**If Hypothesis 5 (EditorView)**: Changing editorProps will fix issues
**If Hypothesis 6 (Wrong Wrapper)**: Correct class name will be visible in inspector

## Next Steps

1. Execute Hypothesis 1 test first (browser inspection) - most likely to reveal root cause
2. Based on findings, proceed to targeted hypothesis
3. Document actual issue found
4. Implement proper fix based on root cause
