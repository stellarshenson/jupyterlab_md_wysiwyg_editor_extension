# Focused Agentic Testing Plan - Based on Debug Discovery

## Root Cause Identified

**The debug output revealed the smoking gun:**
```css
style="position: absolute; contain: strict; top: 8px; left: 0px; width: 634.397px; height: 860px;"
```

Lumino applies inline styles with `contain: strict` which **blocks scrolling propagation**!

## Revised Agent Tasks (3 Agents Only)

### Agent 1: JupyterLab CSS Rules Hunter
**Mission**: Find the CSS rules causing the white frame and containment

**Search for:**
1. `.jp-Document` CSS rules (likely source of white frame/padding)
2. `.jp-MainAreaWidget-ContainStrict` rules (containment)
3. `.lm-Widget` default styles (Lumino base)

**Commands**:
```bash
# Find jp-Document styles
grep -rn "jp-Document" node_modules/@jupyterlab/*/style/*.css

# Find MainAreaWidget styles
grep -rn "jp-MainAreaWidget" node_modules/@jupyterlab/*/style/*.css

# Find Lumino widget positioning
grep -rn "lm-Widget" node_modules/@lumino/widgets/style/*.css | grep -E "(position|contain)"
```

**Deliverable**: `tmp/agent1-jupyterlab-css-rules.md`

**Questions**:
- What padding/background does `.jp-Document` have?
- What does `.jp-MainAreaWidget-ContainStrict` apply?
- Can we override `contain: strict` or do we need to work with it?

---

### Agent 2: CSS Containment & Absolute Positioning Expert
**Mission**: Research how to make scrolling work with `contain: strict` and `position: absolute`

**Research**:
1. How does `contain: strict` affect overflow behavior?
2. Can flex layout work inside `position: absolute` elements?
3. What CSS is needed to enable scrolling with containment?
4. Are there alternatives to overriding with !important?

**Create test HTML**:
```html
<div style="position: absolute; contain: strict; height: 400px; width: 600px;">
  <div style="display: flex; flex-direction: column; height: 100%;">
    <div style="flex-shrink: 0; padding: 8px;">Toolbar</div>
    <div style="flex: 1; overflow-y: auto;">
      <div style="padding: 16px;">Long content...</div>
    </div>
  </div>
</div>
```

**Deliverable**: `tmp/agent2-containment-test.html` + `tmp/agent2-findings.md`

**Questions**:
- Does scrolling work with `contain: strict`?
- Do we need `contain: none` override?
- What's the proper way to handle this in JupyterLab?

---

### Agent 3: Working Solution Validator
**Mission**: Find existing JupyterLab widgets that handle scrolling correctly

**Search for**:
1. Other JupyterLab editors/viewers that scroll (CodeMirror, notebook cells)
2. How they handle the containment and absolute positioning
3. What CSS patterns they use

**Commands**:
```bash
# Find CodeMirror editor CSS
grep -rn "CodeMirror" node_modules/@jupyterlab/codemirror/style/*.css | grep -E "(overflow|scroll)"

# Find notebook cell CSS
grep -rn "jp-Cell" node_modules/@jupyterlab/cells/style/*.css | grep -E "(overflow|scroll)"

# Find any widget with overflow
grep -rn "overflow.*auto" node_modules/@jupyterlab/*/style/*.css | head -20
```

**Deliverable**: `tmp/agent3-working-patterns.md`

**Questions**:
- How do other JupyterLab widgets handle scrolling?
- Do they override containment?
- What CSS patterns actually work?

---

## Immediate Test (Before Agents)

Let me create a quick test fix to validate the hypothesis:

**Test Fix**:
```css
/* Override Lumino's containment */
.jp-MarkdownEditor {
  contain: none !important;  /* MUST override inline strict */
}

/* Ensure flex works with absolute positioning */
.jp-MarkdownEditor {
  display: flex !important;
  flex-direction: column !important;
}

/* Fix scrolling */
.jp-MarkdownEditor-content {
  flex: 1;
  min-height: 0;
  overflow-y: auto !important;
}

/* Remove white frame from parent */
.jp-Document {
  padding: 0 !important;
  background: none !important;
}
```

## Decision Point

**Option A**: Run quick test first
- Apply test fix
- Rebuild and test
- If it works, refine and remove !important where possible
- Skip agents if fix works

**Option B**: Run agents to find proper solution
- 3 agents investigate (10 min)
- Find the "right way" to handle this
- Implement clean solution based on findings

## Recommendation

**Run Option A first** - we know the root cause, let's test the fix.

If the test works:
- We can refine the CSS
- Search for proper selectors to avoid !important
- Document why some !important are necessary (inline styles)

If the test doesn't work:
- Run agents to find what we're missing
- There might be additional constraints

## The Plan

1. Apply test fix to CSS
2. Rebuild extension
3. Test if scrolling/margins work
4. If YES: Refine CSS, remove unnecessary !important
5. If NO: Launch 3 agents to investigate further

**What do you think? Should we:**
- A) Try the test fix immediately
- B) Run the 3 agents first to find the "proper" solution
- C) Do both in parallel

