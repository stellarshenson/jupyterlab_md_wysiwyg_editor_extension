# Agentic Testing Plan - WYSIWYG Editor CSS Issues

## Executive Summary

We cannot directly access the browser to inspect the rendered output, so we'll use 5 parallel agents to test hypotheses about why CSS isn't applying correctly. Each agent will investigate a different aspect and report findings.

## The Problem

Three critical issues persist despite CSS changes:
1. **White frame/border** around editor content
2. **No margins/padding** on content (text touches edges)
3. **No scrolling** functionality (no scrollbar, mouse wheel doesn't work)

**Evidence CSS is loading**: Background color changes, toolbar renders correctly

## Agent Tasks

### Agent 1: JupyterLab DocumentWidget Structure Inspector
**Hypothesis**: DOM structure mismatch - we're targeting wrong elements

**Mission**:
- Search JupyterLab source code for DocumentWidget DOM structure
- Find what CSS classes DocumentWidget actually creates
- Identify wrapper elements and their default styles
- Document actual vs expected hierarchy

**Search Commands**:
```bash
# Find DocumentWidget structure
grep -rn "DocumentWidget" node_modules/@jupyterlab/docregistry/lib/*.d.ts
grep -rn "jp-Document" node_modules/@jupyterlab/docregistry/style/ --include="*.css"

# Find Lumino Widget structure
grep -rn "lm-Widget" node_modules/@lumino/widgets/style/ --include="*.css"
```

**Deliverable**: `tmp/agent1-dom-structure.md`

**Questions to Answer**:
- What is the actual DOM hierarchy from DocumentWidget down to our widget?
- What classes are applied to wrapper elements?
- Are there default paddings/margins on wrappers?

---

### Agent 2: CSS Specificity & Conflicts Analyzer
**Hypothesis**: JupyterLab styles have higher specificity than ours

**Mission**:
- Find all CSS rules that could affect document widgets
- Calculate specificity of conflicting rules
- Identify why background-color applies but padding/overflow doesn't
- Find proper selectors to use without !important

**Search Commands**:
```bash
# Find overflow rules
grep -rn "overflow" node_modules/@jupyterlab/*/style/*.css | grep -v "node_modules.*node_modules"

# Find padding rules on widgets
grep -rn "padding" node_modules/@lumino/widgets/style/*.css

# Find flex rules
grep -rn "flex.*:" node_modules/@jupyterlab/*/style/*.css | head -50
```

**Deliverable**: `tmp/agent2-css-conflicts.md`

**Questions to Answer**:
- What CSS rules are overriding our padding/overflow?
- What is the specificity of conflicting rules?
- What selectors should we use for proper specificity?

---

### Agent 3: Flexbox Scrolling Test
**Hypothesis**: Flexbox layout prevents scrolling from working

**Mission**:
- Create minimal HTML test case with same flex structure
- Test if `overflow-y: auto` works with `flex: 1 1 auto`
- Identify parent constraints needed for scrolling
- Test alternative layouts (explicit height, grid, etc.)

**Test Structure**:
```html
<div style="display: flex; flex-direction: column; height: 400px;">
  <div style="flex-shrink: 0;">Toolbar</div>
  <div style="flex: 1 1 auto; overflow-y: auto; min-height: 0;">
    <div style="padding: 16px 32px;">Content...</div>
  </div>
</div>
```

**Deliverable**: `tmp/agent3-flexbox-test.html` + `tmp/agent3-findings.md`

**Questions to Answer**:
- Does scrolling work in isolation with same structure?
- Is `min-height: 0` required?
- What parent constraints are necessary?

---

### Agent 4: TipTap/ProseMirror Configuration Expert
**Hypothesis**: TipTap configuration or inline styles override CSS

**Mission**:
- Research TipTap editorProps documentation
- Check if padding should be set via attributes
- Find ProseMirror scrolling best practices
- Look for examples of TipTap in flex containers

**Research URLs**:
- TipTap docs: https://tiptap.dev/docs/editor/api/editor
- ProseMirror docs: https://prosemirror.net/docs/ref/
- Search for "tiptap scroll" and "tiptap padding" examples

**Deliverable**: `tmp/agent4-tiptap-config.md`

**Questions to Answer**:
- Should padding be set via editorProps.attributes?
- Are there scroll-related configuration options?
- Does ProseMirror apply inline styles that override CSS?

---

### Agent 5: Alternative CSS Strategies
**Hypothesis**: Different CSS approach might work better

**Mission**:
- Test using data attributes instead of classes
- Test CSS containment properties
- Test :where() and :is() selectors for lower specificity
- Find working CSS patterns for similar scenarios

**Test Approaches**:
```css
/* Data attribute selector */
[data-jp-markdown-editor] { }

/* CSS containment */
.jp-MarkdownEditor-content {
  contain: size layout;
}

/* Lower specificity */
:where(.jp-MarkdownEditor-content) { }
```

**Deliverable**: `tmp/agent5-alternative-css.md`

**Questions to Answer**:
- Do attribute selectors work better?
- Can CSS containment help?
- What's the minimal CSS needed for scrolling?

---

## Execution Strategy

### Phase 1: Parallel Investigation (10 minutes)
```
Launch all 5 agents simultaneously in one message with 5 Task tool calls
```

Each agent works independently on their hypothesis.

### Phase 2: Results Synthesis (5 minutes)
1. Read all agent deliverables
2. Identify common findings
3. Determine root cause
4. Rank solutions by likelihood of success

### Phase 3: Implementation (5 minutes)
1. Apply the fix based on validated hypothesis
2. Remove all !important flags
3. Use proper CSS specificity
4. Test one more time

### Phase 4: Cleanup
1. Remove debug logging from widget.ts
2. Document solution in tmp/SOLUTION.md
3. Rebuild extension

## Success Criteria

The plan succeeds if we:
1. ✓ Identify the root cause from agent findings
2. ✓ Implement fix without !important
3. ✓ White frame disappears
4. ✓ Margins appear on content (32px horizontal, 16px vertical)
5. ✓ Scrolling works properly

## Fallback Plan

If agents don't find clear answer:
1. Create minimal reproduction case
2. Test with explicit positioning instead of flex
3. Use TipTap editorProps as workaround for padding
4. Document as "temporary workaround" and file issue

## Ready to Execute

**Command to launch all agents**:
```
Use Task tool 5 times in single message:
- Agent 1: subagent_type="general-purpose"
- Agent 2: subagent_type="general-purpose"
- Agent 3: subagent_type="general-purpose"
- Agent 4: subagent_type="general-purpose"
- Agent 5: subagent_type="general-purpose"
```

Each gets their specific task from above sections.
